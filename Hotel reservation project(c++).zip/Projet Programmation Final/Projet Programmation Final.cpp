#include <iostream>
#include <string>
#include <fstream>
#include <filesystem>
#include <cmath>

using namespace std;

struct date {
    int jour;
    int mois;
    int annee;
};

struct chambre {
    int num;
    string adresse;
    string type;
    double prix;
    string* options;
    date date_debut;
    date date_fin;
};

struct Client {
    int ID;
    string nom;
    string prenom;
    string mot_de_passe;
    string adresse;
    string tel;
    chambre* c;
};
struct Facture {
    int nb;
    date debut;
    date fin;
    double prix;
};
bool is_all_alpha(string str)
{
    int i = 0;
    while (str[i])
    {
        if (!isalpha(str[i]))
            return false;
        i++;
    }
    return true;
}

bool new_motdepasse(string str)
{
    bool lettre = 0, num = 0, car = 0;
    int i = 0;
    if (str.length() >= 8)
    {
        while (str[i])
        {
            if (isalpha(str[i]))
                lettre = 1;
            else
                if (isdigit(str[i]))
                    num = 1;
                else
                    car = 1;
            i++;

        }
        if (car == 1 && num == 1 && lettre == 1)
            return true;
        return false;
    }
    else
        return 0;

}
bool comp_email(string str, fstream& f)
{
    int id;
    string prenom, nom, email, motdepasse, numtel, l;

    f.close();
    f.open("Client.txt", ios::app | ios::in | ios::out);
    while (f)
    {

        f >> id;
        getline(f, l, '\t');
        getline(f, prenom, '\t');
        getline(f, nom, '\t');
        getline(f, motdepasse, '\t');
        getline(f, email, '\t');
        getline(f, numtel, '\n');

        if (str == email)
            return 0;
    }
    f.close();
    return 1;
}
bool new_email(string str)
{
    bool at = 0, dot = 0;
    int i = 0, id;

    while (str[i])
    {
        if (str[i] == '@')
            at = 1;
        if (str[i] == '.')
            dot = 1;
        i++;
    }
    if (at == 1 && dot == 1)
        return true;
    return false;
}

bool new_numtel(string nb)
{
    if (nb.length() == 9 && nb[2] == '-')
    {
        if (nb[0] == '7' && nb[1] == '1')
            return true;
        else
            if (nb[0] == '7' && nb[1] == '6')
                return true;
            else
                if (nb[0] == '8' && nb[1] == '1')
                    return true;
                else
                    if (nb[0] == '0' && nb[1] == '3')
                        return true;
                    else
                        if (nb[0] == '7' && nb[1] == '0')
                            return true;
                        else
                            return false;
    }
    else
        return false;
}

int generateID(fstream& f)
{
    int nouvel_id = 1, id;
    string prenom, nom, email, motdepasse, numtel;
    f.open("Client.txt", ios::app | ios::out | ios::in);
    while (f)
    {
        f >> id;
        nouvel_id = id + 1;
        getline(f, prenom, '\t');
        getline(f, nom, '\t');
        getline(f, motdepasse, '\t');
        getline(f, email, '\t');
        getline(f, numtel, '\n');
    }
    f.close();
    return nouvel_id;
}

bool passcorrecte(fstream& f, string password, string emailtn, Client* ptr)
{

    string id, prenom, nom, email, motdepasse, numtel;
    f.close();
    f.open("Client.txt", ios::app | ios::out | ios::in);
    while (f)
    {

        getline(f, id, '\t');
        getline(f, prenom, '\t');
        getline(f, nom, '\t');
        getline(f, motdepasse, '\t');
        getline(f, email, '\t');
        getline(f, numtel, '\n');
        if (password == motdepasse && email == emailtn)
        {
            ptr->ID = stoi(id);
            ptr->prenom = prenom;
            ptr->nom = nom;
            ptr->mot_de_passe = motdepasse;
            ptr->adresse = email;
            ptr->tel = numtel;
            return 1;
        }

    }
    f.close();
    return 0;
}
bool nouvelle_chambre_nb(int chambrenb, fstream& fchambre)
{
    string nb, add, type, price, car1, car2, car3;
    int nb1;
    fchambre.close();
    fchambre.open("Chambre.txt", ios::in | ios::out | ios::app);
    while (fchambre)
    {
        fchambre >> nb1;
        getline(fchambre, nb, '\t');
        getline(fchambre, add, '\t');
        getline(fchambre, type, '\t');
        getline(fchambre, price, '\t');
        getline(fchambre, car1, '\t');
        getline(fchambre, car2, '\t');
        getline(fchambre, car3, '\n');
        if (chambrenb == nb1)
            return 0;
    }


    return 1;
}
void ajouter_une_chambre()
{
    fstream fchambre("Chambre.txt", ios::out | ios::in | ios::app);
    int i = 1, chambrenb, carnb;
    double chambreprix;
    string chambreadresse, chambretype, carsupp, carsupp1 = " ", carsupp2 = " ", carsupp3 = " ";
    do {
        if (i == 1)
            cout << "Entrer le nombre de la nouvelle chambre: ";
        else
            cout << "ce nombre est deja utilise entrer un autre: ";
        cin >> chambrenb;
        i++;

    } while (!nouvelle_chambre_nb(chambrenb, fchambre));
    do {
        cout << "Entrer l'adresse de la chambre(Byblos/Tyre/Beirut/Sidon): ";
        cin.ignore(INT_MAX, '\n');
        cin >> chambreadresse;
    } while (chambreadresse != "Byblos" && chambreadresse != "Tyre" && chambreadresse != "Beirut" && chambreadresse != "Sidon");
    do {
        cout << "Entrer le type de la chambre(single room/double room): ";
        getline(cin, chambretype);
    } while (chambretype != "double room" && chambretype != "single room");
    do {
        cout << "Entrer le prix de la chambre : ";
        cin >> chambreprix;
        cin.ignore(INT_MAX, '\n');
    } while (chambreprix <= 0);
    do {
        cout << "Est-ce qu'il y a des caracteristiques supplementaires?: (oui/non)";
        cin >> carsupp;
    } while (carsupp != "oui" && carsupp != "non");
    if (carsupp == "oui")
    {
        do {
            cout << "combien de caracteristiques? (1,2 ou 3): ";
            cin >> carnb;
            cin.ignore(INT_MAX, '\n');
        } while (carnb != 1 && carnb != 2 && carnb != 3);
        if (carnb == 1)
        {
            cout << "Entrer la caracteristique: ";
            getline(cin, carsupp1);
        }
        if (carnb == 2)
        {
            cout << "Entrer les 2 caracteristiques: ";
            getline(cin, carsupp1);
            getline(cin, carsupp2);
        }
        if (carnb == 3)
        {
            cout << "Entrer les 3 caracteristiques: ";
            getline(cin, carsupp1);
            getline(cin, carsupp2);
            getline(cin, carsupp3);
        }
    }
    fchambre.close();
    fchambre.open("Chambre.txt", ios::in | ios::out | ios::app);
    fchambre << chambrenb << "\t" << chambreadresse << "\t" << chambretype << "\t" << chambreprix << "$\t" << carsupp1 << "\t" << carsupp2 << "\t" << carsupp3 << "\n";
}

void supprimer_une_chambre(fstream& fchambre)
{

    string nb, add, type, price, car1, car2, car3;
    int nb1, nb2;
    int i = 1;
    do {
        if (i == 1)
            cout << "Entrer le nombre de la chambre a supprimer: ";
        else
            cout << "nombre n'existe pas entrer un autre: ";
        cin >> nb2;
        cin.ignore(INT_MAX, '\n');
        i++;

    } while (nouvelle_chambre_nb(nb2, fchambre));
    int k = 0, indice;
    fchambre.close();
    fchambre.open("Chambre.txt", ios::in | ios::out);
    while (fchambre)
    {
        fchambre >> nb1;
        getline(fchambre, nb, '\t');
        getline(fchambre, add, '\t');
        getline(fchambre, type, '\t');
        getline(fchambre, price, '\t');
        getline(fchambre, car1, '\t');
        getline(fchambre, car2, '\t');
        getline(fchambre, car3, '\n');
        k++;
        if (nb1 == nb2)
            indice = k;

    }
    k = 0;
    string line;
    fstream temp("temp.txt", ios::in | ios::out);
    fchambre.close();
    fchambre.open("Chambre.txt", ios::in | ios::out);
    while (fchambre)
    {
        k++;
        getline(fchambre, line, '\n');
        if (k != indice)
        {
            temp << line << endl;
            cout << line;
        }

    }
    temp.close();
    temp.open("temp.txt", ios::in | ios::out);
    fchambre.close();
    fchambre.open("Chambre.txt", ios::in | ios::out);
    while (temp)
    {
        getline(temp, line, '\n');
        fchambre << line << endl;
    }
}

void modifier_une_chambre(fstream& fchambre)
{
    string nb, add, type, price, car1, car2, car3, carsupp;
    int chambrenb, nb1, carnb, prix;
    int i = 1;
    do {
        if (i == 1)
            cout << "Entrer le nombre de la chambre a modifier: ";
        else
            cout << "nombre n'existe pas entrer un autre: ";
        cin >> chambrenb;
        cin.ignore(INT_MAX, '\n');
        i++;

    } while (nouvelle_chambre_nb(chambrenb, fchambre));

    int k = 0, indice;
    fchambre.close();
    fchambre.open("Chambre.txt", ios::in | ios::out);
    while (fchambre)
    {
        k++;
        fchambre >> nb1;
        getline(fchambre, nb, '\t');
        getline(fchambre, add, '\t');
        getline(fchambre, type, '\t');
        getline(fchambre, price, '\t');
        getline(fchambre, car1, '\t');
        getline(fchambre, car2, '\t');
        getline(fchambre, car3, '\n');

        if (chambrenb == nb1)
            indice = k;

    }
    k = 0;
    string line;
    fstream temp("temp.txt", ios::in | ios::out);
    fchambre.close();
    fchambre.open("Chambre.txt", ios::in | ios::out);
    while (fchambre)
    {
        k++;
        getline(fchambre, line, '\n');
        if (k != indice)
            temp << line << endl;

    }
    car1 = " "; car2 = " "; car3 = " ";
    temp.close();
    temp.open("temp.txt", ios::in | ios::out);
    fchambre.close();
    fchambre.open("Chambre.txt", ios::in | ios::out);
    while (!temp.eof())
    {
        getline(temp, line, '\n');
        fchambre << line << endl;
    }
    do {
        cout << "Entrer l'adresse de la chambre(Byblos/Tyre/Beirut/Sidon): ";
        cin >> add;
    } while (add != "Byblos" && add != "Tyre" && add != "Beirut" && add != "Sidon");
    do {
        cout << "Entrer le type de la chambre(single room/double room): ";
        cin.ignore(INT_MAX, '\n');
        getline(cin, type);
    } while (type != "double room" && type != "single room");
    do {
        cout << "Entrer le prix de la chambre : ";
        cin >> prix;
        cin.ignore(INT_MAX, '\n');
    } while (prix <= 0);
    do {
        cout << "Est-ce qu'il y a des caracteristiques supplementaires?: (oui/non)";
        cin >> carsupp;
    } while (carsupp != "oui" && carsupp != "non");
    if (carsupp == "oui")
    {
        do {
            cout << "combien de caracteristiques? (1,2 ou 3): ";
            cin >> carnb;
            cin.ignore(INT_MAX, '\n');
        } while (carnb != 1 && carnb != 2 && carnb != 3);
        if (carnb == 1)
        {
            cout << "Entrer la caracteristique: ";
            getline(cin, car1);
        }
        if (carnb == 2)
        {
            cout << "Entrer les 2 caracteristiques: ";
            getline(cin, car1);
            getline(cin, car2);
        }
        if (carnb == 3)
        {
            cout << "Entrer les 3 caracteristiques: ";
            getline(cin, car1);
            getline(cin, car2);
            getline(cin, car3);
        }
    }
    fchambre.close();
    fchambre.open("Chambre.txt", ios::in | ios::out | ios::app);
    fchambre << chambrenb << "\t" << add << "\t" << type << "\t" << prix << "$\t" << car1 << "\t" << car2 << "\t" << car3 << "\n";

}
bool chambre_reservee(int chambrenb, date debut, date fin)
{
    string nb, prenom, nom, jourdebut, moisdebut, anneedebut, jourfin, moisfin, anneefin;
    int jd, md, ad, fj, fm, fa, nb1;
    fstream freservation("Reservation.txt", ios::in | ios::out | ios::app);
    /*freservation.close();
    freservation.open("Reservation.txt", ios::in | ios::out | ios::app);*/
    while (!freservation.eof())
    {

        freservation >> nb1;
        getline(freservation, nb, '\t');
        getline(freservation, prenom, '\t');
        getline(freservation, nom, '\t');
        getline(freservation, jourdebut, '-');
        getline(freservation, moisdebut, '-');
        getline(freservation, anneedebut, '\t');
        getline(freservation, jourfin, '-');
        getline(freservation, moisfin, '-');
        getline(freservation, anneefin, '\n');
        ad = stoi(anneedebut);
        fa = stoi(anneefin);
        md = stoi(moisdebut);
        fm = stoi(moisfin);
        jd = stoi(jourdebut);
        fj = stoi(jourfin);

        if (chambrenb == nb1)
        {
            if (debut.annee < ad && fin.annee < ad)
                return 0;
            else
                if (debut.annee > fa && fin.annee > fa)
                    return 0;
                else
                    if (debut.mois < md && fin.mois < md)
                        return 0;
                    else
                        if (debut.mois > fm && fin.mois > fm)
                            return 0;
                        else
                            if (debut.jour < jd && fin.jour < jd)
                                return 0;
                            else
                                if (debut.jour > fj && fin.jour > fj)
                                    return 0;
                                else
                                    return 1;
        }
        else
            return 0;
    }
    return 0;
}
bool dates_fin_debut(date debut, date fin)
{
    if (debut.annee < fin.annee)
        return 1;
    else
        if (debut.mois < fin.mois)
            return 1;
        else
            if (debut.jour < fin.jour)
                return 1;
            else return 0;
}
void remplir_chambre_struct(chambre& chambre_res)
{
    int prix, nb1;
    string nb, add, type, price, car1, car2, car3;
    fstream fchambre("Chambre.txt", ios::in | ios::out);
    while (fchambre)
    {
        fchambre >> nb1;
        getline(fchambre, nb, '\t');
        getline(fchambre, add, '\t');
        getline(fchambre, type, '\t');
        getline(fchambre, price, '\t');
        getline(fchambre, car1, '\t');
        getline(fchambre, car2, '\t');
        getline(fchambre, car3, '\n');
        if (chambre_res.num == nb1)
        {
            chambre_res.adresse = add;
            chambre_res.type = type;
            prix = stoi(price);
            chambre_res.prix = prix;
            chambre_res.adresse = add;


        }
    }
}
bool nb_existe_dans_reservation(int nbroom, Client& client_struct)
{
    string nb, prenom, nom, jourdebut, moisdebut, anneedebut, jourfin, moisfin, anneefin;
    fstream reservation("Reservation.txt", ios::in | ios::out);
    cout << "La liste de vos reservations: ";
    while (reservation)
    {
        getline(reservation, nb, '\t');
        getline(reservation, prenom, '\t');
        getline(reservation, nom, '\t');
        getline(reservation, jourdebut, '-');
        getline(reservation, moisdebut, '-');
        getline(reservation, anneedebut, '\t');
        getline(reservation, jourfin, '-');
        getline(reservation, moisfin, '-');
        getline(reservation, anneefin, '\n');
        if (prenom == client_struct.prenom && nom == client_struct.nom && nbroom == stoi(nb))
            return 1;
    }
    return 0;
}
void annuler_reservation(chambre& chambre_res, Client& client_struct)
{
    int annul_num;
    bool there_is = 0;
    string nb, prenom, nom, jourdebut, moisdebut, anneedebut, jourfin, moisfin, anneefin, s;
    fstream reservation("Reservation.txt", ios::in | ios::out);
    cout << "La liste de vos reservations: \n";
    while (reservation)
    {
        getline(reservation, nb, '\t');
        getline(reservation, prenom, '\t');
        getline(reservation, nom, '\t');
        getline(reservation, jourdebut, '-');
        getline(reservation, moisdebut, '-');
        getline(reservation, anneedebut, '\t');
        getline(reservation, jourfin, '-');
        getline(reservation, moisfin, '-');
        getline(reservation, anneefin, '\n');
        if (prenom == client_struct.prenom && nom == client_struct.nom)
        {
            there_is = 1;
            cout << nb << "\t" << prenom << "\t" << nom << "\t" << jourdebut << "-" << moisdebut << "-" << anneedebut << "\t" << jourfin << "-" << moisfin << "-" << anneefin << "\n";
        }
    }
    if (!there_is)
    {
        cout << "Vous n'avez pas de reservations!";
        return;
    }
    else
    {
        int i = 1;
        do {
            if (i == 1)
                cout << "Entrer le numero de la chambre: ";
            else
                cout << "numero n'existe pas entrer de nouveau: ";
            cin >> annul_num;
            i++;
        } while (!nb_existe_dans_reservation(annul_num, client_struct));
        int nb1;
        fstream temp("temp_reservation.txt", ios::out | ios::in);
        reservation.close();
        reservation.open("Reservation.txt", ios::out | ios::in);
        while (reservation)
        {
            reservation >> nb1;

            getline(reservation, nb, '\t');
            getline(reservation, prenom, '\t');
            getline(reservation, nom, '\t');
            getline(reservation, jourdebut, '-');
            getline(reservation, moisdebut, '-');
            getline(reservation, anneedebut, '\t');
            getline(reservation, jourfin, '-');
            getline(reservation, moisfin, '-');
            getline(reservation, anneefin, '\n');

            /*if (prenom == client_struct.prenom && nom == client_struct.nom)*/
            if (nb1 != annul_num)
                temp << nb1 << "\t" << prenom << "\t" << nom << "\t" << jourdebut << "-" << moisdebut << "-" << anneedebut << "\t" << jourfin << "-" << moisfin << "-" << anneefin << "\n";
        }
        int mnb1;
        temp.close();

        cout << "hi";
        reservation.close();
        reservation.open("Reservation.txt", ios::out | ios::in);

        while (temp)
        {
            cout << "g";

            temp >> mnb1;
            getline(temp, nb, '\t');
            getline(temp, prenom, '\t');
            getline(temp, nom, '\t');
            getline(temp, jourdebut, '-');
            getline(temp, moisdebut, '-');
            getline(temp, anneedebut, '\t');
            getline(temp, jourfin, '-');
            getline(temp, moisfin, '-');
            getline(temp, anneefin, '\n');


        }
        temp.close();
        temp.open("temp_reservation.txt", ios::out | ios::in);
        while (temp)
        {
            cout << "g";

            temp >> mnb1;
            getline(temp, nb, '\t');
            getline(temp, prenom, '\t');
            getline(temp, nom, '\t');
            getline(temp, jourdebut, '-');
            getline(temp, moisdebut, '-');
            getline(temp, anneedebut, '\t');
            getline(temp, jourfin, '-');
            getline(temp, moisfin, '-');
            getline(temp, anneefin, '\n');
            reservation << mnb1 << "\t" << prenom << "\t" << nom << "\t" << jourdebut << "-" << moisdebut << "-" << anneedebut << "\t" << jourfin << "-" << moisfin << "-" << anneefin << "\n";


        }
    }
}
void reserver(chambre& chambre_res)
{
    string nb, add, type, price, car1, car2, car3;
    int nb1, chambrenb, chambre_res_nb;
    date debut, fin;
    fstream fchambre("Chambre.txt", ios::in | ios::out);

    do {
        do {
            cout << "Entrer le jour de debut: ";
            cin >> debut.jour;
        } while (debut.jour <= 0 || debut.jour > 30);
        do {
            cout << "Entrer le mois de debut: ";
            cin >> debut.mois;
        } while (debut.mois <= 0 || debut.mois > 12);
        do {
            cout << "Entrer l'annee de debut: ";
            cin >> debut.annee;
        } while (debut.annee < 2022);

        do {
            cout << "Entrer le jour de fin: ";
            cin >> fin.jour;
        } while (fin.jour <= 0 || fin.jour > 30);
        do {
            cout << "Entrer le mois de fin: ";
            cin >> fin.mois;
        } while (fin.mois <= 0 || fin.mois > 12);
        do {
            cout << "Entrer l'annee de fin: ";
            cin >> fin.annee;
        } while (fin.annee < 2022);
    } while (!dates_fin_debut(debut, fin));
    bool reservee = 0;
    fchambre.close();
    fchambre.open("Chambre.txt", ios::in | ios::out);
    cin.ignore(INT_MAX, '\n');
    while (fchambre)
    {
        fchambre >> nb1;
        getline(fchambre, nb, '\t');
        getline(fchambre, add, '\t');
        getline(fchambre, type, '\t');
        getline(fchambre, price, '\t');
        getline(fchambre, car1, '\t');
        getline(fchambre, car2, '\t');
        getline(fchambre, car3, '\n');

        if (!chambre_reservee(nb1, debut, fin))
        {
            cout << nb1 << "\t" << add << "\t" << type << "\t" << price << "\t" << car1 << "\t" << car2 << "\t" << car3 << "\n";
            reservee = 1;
        }

    }
    if (!reservee)
        cout << "pas de chambres dans cette date";
    chambre_res.date_debut = debut;
    chambre_res.date_fin = fin;
    do {
        cout << "Entrer le numero de la chambre: ";
        cin >> chambre_res.num;
    } while (chambre_reservee(chambre_res.num, debut, fin));
    cout << chambre_res.num;
    remplir_chambre_struct(chambre_res);

}
void copier_au_fichier(Client* ptr, fstream& clienttxt)
{
    clienttxt.open("Client.txt", ios::app | ios::out | ios::in);
    clienttxt << ptr->ID << "\t" << ptr->prenom << "\t" << ptr->nom << "\t" << ptr->mot_de_passe << "\t" << ptr->adresse << "\t" << ptr->tel << "\n";
    clienttxt.close();
}
void ancienclient(fstream&, Client*);
void nouveauclient(Client* client_ptr, fstream& f)
{
    string login;
    string nom, prenom, email, num_tel, motdepasse;
    cout << "Creation d'un nouveau compte\nSVP Entrer les informations attentivement:" << endl;

    do {
        cout << "Prenom (ne doit contenir que des lettres): ";
        cin >> prenom;
        client_ptr->prenom = prenom;
    } while (!is_all_alpha(prenom));
    do {
        cout << "Nom (ne doit contenir que des lettres): ";
        cin >> nom;
        client_ptr->nom = nom;
    } while (!is_all_alpha(nom));
    do {
        cout << "Entrez votre mot de passe(8 caracteres contenant: chiffres,lettres,caracteres speciaux): " << endl;
        cin >> motdepasse;
        client_ptr->mot_de_passe = motdepasse;
    } while (!new_motdepasse(motdepasse));
    do {
        cout << "Entrer votre e-mail avec le bon format: ";
        cin >> email;
        client_ptr->adresse = email;
        if (!comp_email(email, f))
        {
            cout << "Cet email existe deja vous voulez passer au Log In?(oui/non)";
            cin >> login;
            if (login == "oui")
            {
                ancienclient(f, client_ptr);
                return;
            }

        }
    } while (!new_email(email) || !comp_email(email, f));
    do {
        cout << "Entrez votre numero de telephone valide(format: 12-345678): ";
        cin >> num_tel;
        client_ptr->tel = num_tel;
    } while (!new_numtel(num_tel));
    if (generateID(f) > 0)
        client_ptr->ID = generateID(f);
    else
        client_ptr->ID = 1;
    copier_au_fichier(client_ptr, f);
}

void ancienclient(fstream& f, Client* ptr_struct_client)
{
    string emailtn, motdepassetn, email, password, nom, prenom, tel, id, signin;
    int j = 1;
    do {

        cout << "Entrer votre email: ";
        cin >> emailtn;

        if (comp_email(emailtn, f))
        {
            cout << "Cet email n'existe pas vous voulez passer au Create Account?(oui/non)";
            cin >> signin;
            if (signin == "oui")
            {
                nouveauclient(ptr_struct_client, f);
                return;
            }

        }
    } while (comp_email(emailtn, f) || !new_email(emailtn));
    do {
        if (j == 1)
            cout << "Entrer mot de passe: ";
        else
            cout << "Mot de passe incorrect, entrer de nouveau: ";
        cin >> motdepassetn;
        j++;
    } while (!passcorrecte(f, motdepassetn, emailtn, ptr_struct_client));
    f.close();
    f.open("Client.txt", ios::in | ios::out | ios::app);
    while (f)
    {
        f.open("Client.txt", ios::app | ios::out | ios::in);
        getline(f, id, '\t');
        getline(f, prenom, '\t');
        getline(f, nom, '\t');
        getline(f, password, '\t');
        getline(f, email, '\t');
        getline(f, tel, '\t');
        if (email == emailtn)
        {
            ptr_struct_client->ID = stoi(id);
            ptr_struct_client->prenom = prenom;
            ptr_struct_client->mot_de_passe = password;
            ptr_struct_client->adresse = email;
            ptr_struct_client->tel = tel;
        }

    }
    cout << "Bienvenue " << ptr_struct_client->prenom << " !" << endl;

}

void un_admin()
{
    char choix = 'a';
    fstream fchambre("Chambre.txt", ios::in | ios::out | ios::app);
    while (choix != 'd')
    {
        do {
            cout << "Qu'est-ce que vous desirez faire:\na)ajouter une chambre\nb)supprimer une chambre\nc)modifier une chambre existante\nd)quitter le programme?";
            cin >> choix;
        } while (choix != 'a' && choix != 'b' && choix != 'c' && choix != 'd');
        switch (choix)
        {
        case 'a': ajouter_une_chambre();break;
        case 'b': supprimer_une_chambre(fchambre);break;
        case 'c': modifier_une_chambre(fchambre);break;
        }
    }

}
void un_client(chambre& chambre_res, Client& client_struct)
{
    char choix;
    fstream fchambre("Chambre.txt", ios::in | ios::out | ios::app);
    fstream freservation("Reservation.txt", ios::in | ios::out | ios::app);
    do {
        cout << "Vous voulez reserver une chambre(o) ou annuler une reservation(n)? ";
        cin >> choix;
    } while (choix != 'o' && choix != 'n');

    switch (choix)
    {
    case 'o': {
        reserver(chambre_res);
        freservation << chambre_res.num << "\t" << client_struct.prenom << "\t" << client_struct.nom << "\t" << chambre_res.date_debut.jour << "-" << chambre_res.date_debut.mois << "-" << chambre_res.date_debut.annee << "\t" << chambre_res.date_fin.jour << "-" << chambre_res.date_fin.mois << "-" << chambre_res.date_fin.annee << "\n";
        break;}
    case 'n': annuler_reservation(chambre_res, client_struct);break;
    }
}
void Prix_Total(fstream& clienttxt, Client client_struct)
{
    int taille = 0,i=0;
    
    fstream reservation("Reservation.txt", ios::in | ios::in);
    fstream facture("Facture.pdf", ios::in | ios::out | ios::app);
    fstream chambretxt("Chambre.txt", ios::in | ios::out);
    int nb1, nb2, nbuser, sum = 0;
    facture << "\nClient: " << client_struct.prenom << " " << client_struct.nom << "\n";
    string nb, prenom, nom, jourdebut, moisdebut, anneedebut, jourfin, moisfin, anneefin, s;
    string  add, type, price, car1, car2, car3;
    while (reservation)
    {
        reservation >> nb1;
        getline(reservation, nb, '\t');
        getline(reservation, prenom, '\t');
        getline(reservation, nom, '\t');
        getline(reservation, jourdebut, '-');
        getline(reservation, moisdebut, '-');
        getline(reservation, anneedebut, '\t');
        getline(reservation, jourfin, '-');
        getline(reservation, moisfin, '-');
        getline(reservation, anneefin, '\n');
        if (prenom == client_struct.prenom && nom == client_struct.nom)
            taille++;
    }
    reservation.close();
    reservation.open("Reservation.txt", ios::in | ios::in);
    Facture* bill = new Facture[taille];
    while (reservation)
    {
        reservation >> nb1;
        getline(reservation, nb, '\t');
        getline(reservation, prenom, '\t');
        getline(reservation, nom, '\t');
        getline(reservation, jourdebut, '-');
        getline(reservation, moisdebut, '-');
        getline(reservation, anneedebut, '\t');
        getline(reservation, jourfin, '-');
        getline(reservation, moisfin, '-');
        getline(reservation, anneefin, '\n');
        int j1, j2, m1, m2, y1, y2;
        j1 = stoi(jourdebut);
        j2 = stoi(jourfin);
        m1 = stoi(moisdebut);
        m2 = stoi(moisfin);
        y1 = stoi(anneedebut);
        y2 = stoi(anneefin);
        int nombredejours = abs(j2 - j1) + 30 * abs(m2 - m1) + 360 * abs(y2 - y1);
        if (prenom == client_struct.prenom && nom == client_struct.nom)
        {
            nbuser = nb1;
            bill[i].nb = nb1;           
            bill[i].debut.jour = stoi(jourdebut);
            bill[i].debut.mois = stoi(moisdebut);
            bill[i].debut.annee = stoi(anneedebut);
            bill[i].fin.jour = stoi(jourfin);
            bill[i].fin.mois = stoi(moisfin);
            bill[i].fin.annee = stoi(anneefin);
            while (chambretxt)
            {
                chambretxt >> nb2;
                getline(chambretxt, nb, '\t');
                getline(chambretxt, add, '\t');
                getline(chambretxt, type, '\t');
                getline(chambretxt, price, '$');
                getline(chambretxt, car1, '\t');
                getline(chambretxt, car2, '\t');
                getline(chambretxt, car3, '\n');

                if (nb2 == nbuser)
                {
                    bill[i].prix = stoi(price)*nombredejours;

                    sum += stoi(price);
                }

            }
            i++;
        }


        chambretxt.close();
        chambretxt.open("Chambre.txt", ios::in | ios::out);
    }
    int nbtemp,prixtemp;
    date debuttemp, fintemp;

    for (int j = 0;j < taille;j++)
    {
        for(int k=0;k<taille;k++)
            if (bill[j].prix < bill[k].prix)
            {
                prixtemp = bill[j].prix;
                bill[j].prix = bill[k].prix;
                bill[k].prix = prixtemp;
                debuttemp = bill[j].debut;
                bill[j].debut = bill[k].debut;
                bill[k].debut = debuttemp;
                fintemp = bill[j].fin;
                bill[j].fin = bill[k].fin;
                bill[k].fin = fintemp;
                nbtemp = bill[j].nb;
                bill[j].nb = bill[k].nb;
                bill[k].nb = nbtemp;

            }
     }
    for (int j = 0;j < taille;j++)
    facture << bill[j].nb << "\t" << bill[j].debut.jour << "-" << bill[j].debut.mois << "-" << bill[j].debut.annee << "\t" << bill[j].fin.jour << "-" << bill[j].fin.mois << "-" << bill[j].fin.annee << "\t" << bill[j].prix << "$\n";
    facture << "\nTotale:\t" << sum*1.11 << "$";
}
int main()
{
    string nouveau_ou_pas, client_ou_admin;/* nom, prenom, motdepasse, email, num_tel;*/
    bool nouveau_utilisateur = false;
    Client client_struct;
    chambre chambre_res;
    client_struct.c = &chambre_res;
    int nbadmin;
    fstream reservation("Reservation.txt", ios::in | ios::out | ios::app);
    fstream clienttxt("Client.txt", ios::in | ios::out | ios::app);
    cout << "Bienvenue a Hotel Nabil!" << endl;
    cout << "Vous etes nouveaux et vous voudriez creer un compte?\nEntrer \"oui\"" << endl;
    cout << "Vous en avez deja un?\nEntrer \"non\":" << endl;
    cin >> nouveau_ou_pas;

    if (nouveau_ou_pas != "oui" && nouveau_ou_pas != "Oui" && nouveau_ou_pas != "non" && nouveau_ou_pas != "Non")
        do {
            cout << "Vous avez entre un mot incomprehensible, SVP entrez \"oui\" ou \"non\": ";
            cin >> nouveau_ou_pas;
        } while (nouveau_ou_pas != "oui" && nouveau_ou_pas != "Oui" && nouveau_ou_pas != "non" && nouveau_ou_pas != "Non");

        if (nouveau_ou_pas == "oui" || nouveau_ou_pas == "Oui")
        {
            nouveauclient(&client_struct, clienttxt);
            clienttxt.open("Client.txt", ios::app | ios::out | ios::in);
            copier_au_fichier(&client_struct, clienttxt);
            clienttxt.close();

        }
        else
        {
            ancienclient(clienttxt, &client_struct);
        }
        do {
            cout << "Est-ce que vous etes administrateur ou client?";
            cin >> client_ou_admin;
        } while (client_ou_admin != "client" && client_ou_admin != "Client" && client_ou_admin != "administrateur" && client_ou_admin != "Administrateur");
        if (client_ou_admin == "client" || client_ou_admin == "Client" || client_ou_admin == "administrateur" || client_ou_admin == "Administrateur")
        {
            if (client_ou_admin == "administrateur" || client_ou_admin == "Administrateur")
            {
                do {
                    cout << "Entrer le password des admins: ";
                    cin >> nbadmin;
                } while (nbadmin != 1234);
                un_admin();
            }
            else
            {
                un_client(chambre_res, client_struct);

            }

        }
        Prix_Total(clienttxt, client_struct);

        return 0;
}