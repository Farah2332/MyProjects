module com.mycompany.projectsis {
    requires javafx.controls;
       requires java.sql;
       
    exports com.mycompany.projectsis;
 
}
