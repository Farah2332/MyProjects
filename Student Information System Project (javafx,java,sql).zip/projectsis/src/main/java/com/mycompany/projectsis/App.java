package com.mycompany.projectsis;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.ScaleTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import static javafx.print.PrintColor.COLOR;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Glow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;


/**
 * JavaFX App
 */
class Course{
    int id,nb_credits,available_seats;
    String c_title,c_day,c_instructor,class_nb,f_name;
    double passing_grade;
    Time c_time;
 
    
    static ArrayList<Course> courses =new ArrayList<>();

    public Course(int id, int nb_credits, int available_seats, String c_title, String c_day, String c_instructor, String class_nb, String f_name, double passing_grade, Time c_time) {
        this.id = id;
        this.nb_credits = nb_credits;
        this.available_seats = available_seats;
        this.c_title = c_title;
        this.c_day = c_day;
        this.c_instructor = c_instructor;
        this.class_nb = class_nb;
        this.f_name = f_name;
        this.passing_grade = passing_grade;
        this.c_time = c_time;
        
    }
      
 
}
class Student{
 
    public Student(String username, String s_password, String firstname, String lastname, String f_name, Date registration_year) {
        this.username = username;
        this.s_password = s_password;
        this.firstname = firstname;
        this.lastname = lastname;
        this.f_name = f_name;
        this.registration_year = registration_year;
    }
String username,s_password,firstname,lastname,f_name;
Date registration_year;
 
}
class Grades {
    String c_title,state;
    Double grade;

    public Grades(String c_title, String state, Double grade) {
        this.c_title = c_title;
        this.state = state;
        this.grade = grade;
    }
    
}
class Absence {
    String c_title;
    Date absence_date;
    int absence_count;

    public Absence(String c_title, Date absence_date, int absenceCount) {
        this.c_title = c_title;
        this.absence_date = absence_date;
        this.absence_count=absence_count;
    }
    
}


public class App extends Application {
     Database d;
    Button b_login_intstructor=new Button("Login as instructor");
    Button b_login_student=new Button("Login as student");
    TextField t_username= new TextField();
    PasswordField t_password=new PasswordField();
    GridPane g=new GridPane();
   
       Image myprof= new Image("file:///C:/Users/farah/Desktop/Semester%205/oop2/projectimages/myprofile.png");
       ImageView myprofview=new ImageView(myprof);
         Image myrecrods= new Image("file:///C:/Users/farah/Desktop/Semester%205/oop2/projectimages/academic_achievement.png");
       ImageView myrecordsview=new ImageView(myrecrods);
           Image myabsences= new Image("file:///C:/Users/farah/Desktop/Semester%205/oop2/projectimages/absences.png");
       ImageView myabsencesview=new ImageView(myabsences);
           Image mycourses= new Image("file:///C:/Users/farah/Desktop/Semester%205/oop2/projectimages/mycourses.png");
       ImageView mycoursesview=new ImageView(mycourses);
           Image courses= new Image("file:///C:/Users/farah/Desktop/Semester%205/oop2/projectimages/courses.jpeg");
           Image student_profile_img= new Image("file:///C:/Users/farah/Desktop/Semester%205/oop2/projectimages/profile.png");
              ImageView studentprofileview=new ImageView(student_profile_img);      
       ImageView coursesview=new ImageView(courses);
            Image teacherprof= new Image("file:///C:/Users/farah/Desktop/Semester%205/oop2/projectimages/teacherprofile.png");
       ImageView teacherprofview=new ImageView(teacherprof);
            Image addgrades= new Image("file:///C:/Users/farah/Desktop/Semester%205/oop2/projectimages/addgrade.png");
       ImageView teachergradesview=new ImageView(addgrades);
            Image addabsences= new Image("file:///C:/Users/farah/Desktop/Semester%205/oop2/projectimages/addabsence.jpg");
       ImageView teacherabsencesview=new ImageView(addabsences);
            Image addstudent= new Image("file:///C:/Users/farah/Desktop/Semester%205/oop2/projectimages/addstudent.png");
       ImageView teacherstudentview=new ImageView(addstudent);
       Button course_return =new Button("Return");
       Button my_course_return =new Button("Return");
       Button profile_return =new Button("Return");
       Button grades_return =new Button("Return");
       Button absence_return =new Button("Return");
       Button logout_student = new Button("Logout");
             Button logout_teacher = new Button("Logout");
             TextField new_username=new TextField();
             TextField new_password=new TextField();
             TextField new_fname=new TextField();
             TextField new_lname=new TextField();
             TextField new_registration_date=new TextField();
             TextField new_faculty=new TextField();
             Button b_add_student=new Button("Add");
             Button add_student_return =new Button("Return");
             Button add_grades_return = new Button("Return");
               Button add_absences_return = new Button("Return");
                 Button teacher_prof_return = new Button("Return");
    @Override
    public void start(Stage stage) throws SQLException {

        d = new Database(this); // Pass the App instance to the Database
        try {
            d.connect();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
          /* Screen screen = Screen.getPrimary();
        Rectangle2D bounds = screen.getVisualBounds();
 
        // Set the stage dimensions to fit the screen
       stage.setX(bounds.getMinX());
        stage.setY(bounds.getMinY());
       stage.setWidth(bounds.getWidth());
       stage.setHeight(bounds.getHeight());*/
   
         Scene scene2=new Scene (Student_home_page(),1600,800);
             b_login_student.setOnAction(e ->{
            String u=t_username.getText();
            String p = t_password.getText();
            if (d.validate_student(u, p))
            {
                System.out.println("validated");
                        showAlert(AlertType.INFORMATION, "Information", "Succesfully logged in!");
                
                stage.setScene(scene2);
                   
              
            }
            else
                   showAlert(AlertType.WARNING, "Warning", "Invalid username or password!");
        });
            
             b_login_intstructor.setOnAction(e ->{
            String u=t_username.getText();
            String p = t_password.getText();
            if (d.validate_instructor(u, p))
            {
                Scene scene8=new Scene (Teacher_home_page(),1600,800);
                System.out.println("validated");
                        showAlert(AlertType.INFORMATION, "Information", "Succesfully logged in!");
                
                stage.setScene(scene8);
                   stage.show();
              
            }
            else
                   showAlert(AlertType.WARNING, "Warning", "Invalid username or password!");
        });
             coursesview.setOnMouseClicked(E->{
                      try {
                            ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), coursesview);
    scaleTransition.setToX(1.1);
    scaleTransition.setToY(1.1);
 
                          var scene3=new Scene (coursesDesign(), 1600, 800);
                          stage.setScene(scene3);
                      
                      } catch (SQLException ex) {
                          Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
                      }
             });
              mycoursesview.setOnMouseClicked(E->{
                      try {
                            ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), mycoursesview);
    scaleTransition.setToX(1.1);
    scaleTransition.setToY(1.1);
 
                          var scene4=new Scene (studentcoursesDesign(), 1600, 800);
                          stage.setScene(scene4);
                       
                      } catch (SQLException ex) {
                          Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
                      }
             });
            myprofview.setOnMouseClicked(e->{
                ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), myprofview);
                scaleTransition.setToX(1.1);
                scaleTransition.setToY(1.1);
                var scene5=new Scene (profileDesign(), 1600, 800);
                stage.setScene(scene5);
                
            });
    myrecordsview.setOnMouseClicked(e->{
            try {
                ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(100), myrecordsview);
                scaleTransition.setToX(1.1);
                scaleTransition.setToY(1.1);
                Scene scene6 = new Scene (gradesDesign(),1600, 800);
                stage.setScene(scene6);
               
            } catch (SQLException ex) {
                Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
            }
            });
    
        myabsencesview.setOnMouseClicked(e->{
            try {
                ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(100), myabsencesview);
                scaleTransition.setToX(1.1);
                scaleTransition.setToY(1.1);
                Scene scene7 = new Scene (absencesDesign(),1600, 800);
                stage.setScene(scene7);
               
            } catch (SQLException ex) {
                Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
            }
            });
                  teacherstudentview.setOnMouseClicked(E->{
                      ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), teacherstudentview);
                      scaleTransition.setToX(1.1);
                      scaleTransition.setToY(1.1);
                      var scene9=new Scene (add_student_design(), 1600, 800);
                      stage.setScene(scene9);
             });
       b_add_student.setOnAction(e -> {
    String u = new_username.getText();
    String p = new_password.getText();
    String f = new_fname.getText();
    String l = new_lname.getText();
    String dateString = new_registration_date.getText();

    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    java.util.Date utilDate = null;

    try {
        utilDate = dateFormat.parse(dateString);
    } catch (ParseException ex) {
        Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
    }

    // Convert java.util.Date to java.sql.Date
    java.sql.Date registrationDate = new java.sql.Date(utilDate.getTime());

    String fc = new_faculty.getText();

    // Assuming 'd' is an instance of the Database class
    d.addStudent(u, p, f, l, registrationDate, fc);
});


        var scene1 = new Scene(loginDesign(),1600,800);
scene1.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());
 
 
       
        stage.setScene(scene1);
           
        stage.show();
    course_return.setOnAction(e->{
    stage.setScene(scene2);
    });
     my_course_return.setOnAction(e->{
    stage.setScene(scene2);
    });
    grades_return.setOnAction(e->{
    stage.setScene(scene2);
    });
    absence_return.setOnAction(e->{
    stage.setScene(scene2);
    }); 
    profile_return.setOnAction(e->{
    stage.setScene(scene2);
    });
    add_absences_return.setOnAction(e->{
    stage.setScene(scene2);
    });
      add_grades_return.setOnAction(e->{
    stage.setScene(scene2);
    });
        add_student_return.setOnAction(e->{
    stage.setScene(scene2);
    });
      teacher_prof_return.setOnAction(e->{
    stage.setScene(scene2);
    });
     logout_student.setOnAction(e->{
    stage.setScene(scene1);
    });    
     logout_teacher.setOnAction(e->{
    stage.setScene(scene1);
    });   
    }
     
   StackPane loginDesign(){
        GridPane gridPane= new GridPane();
 gridPane.setAlignment(Pos.TOP_CENTER);
        gridPane.setVgap(10);
        gridPane.setHgap(10);
    
        Label l_uni=new Label("Student Information System");
           l_uni.setStyle(
                "-fx-text-fill: #1260CC; " +
                "-fx-font-size: 22px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " +
                "-fx-font-style: italic;");
Glow glow = new Glow(0);

// Apply the Glow effect to the Label
l_uni.setEffect(glow);

// Create a Timeline for the glowing animation
Timeline timeline = new Timeline(
        new KeyFrame(Duration.ZERO, new KeyValue(glow.levelProperty(), 0)),
        new KeyFrame(Duration.seconds(1), new KeyValue(glow.levelProperty(), 1))
);

// Set the cycle count to indefinite for continuous animation
timeline.setCycleCount(Timeline.INDEFINITE);

// Auto-reverse the animation to make it smooth
timeline.setAutoReverse(true);

// Play the animation
timeline.play();

        
        // Add the ImageView to the GridPane
        gridPane.add(l_uni, 3, 0, 3, 1);

        // Username components
       Label l_username = new Label("Username:");
        t_username.setPromptText("Enter your username"); // Placeholder
        gridPane.add(l_username, 3, 3);
        gridPane.add(t_username, 4, 3);

        // Password components
        Label l_password = new Label("Password:");
        t_password.setPromptText("Enter your password"); // Placeholder
        gridPane.add(l_password, 3, 4);
        gridPane.add(t_password, 4, 4);

        // Buttons
        gridPane.add(   b_login_intstructor, 4, 8, 2, 1);
        gridPane.add(b_login_student, 4, 10, 7, 1);

        gridPane.setAlignment(Pos.CENTER);
            Rectangle rectangle = new Rectangle(400, 500);
              rectangle.setFill(Color.WHITE);
              rectangle.setOpacity(0.5);
                  StackPane stackPane = new StackPane();
                     stackPane.getChildren().addAll(rectangle, gridPane);

        return stackPane;
    }

   GridPane Student_home_page (){
   
       myprofview.setFitHeight(180);
       myprofview.setFitWidth(180);
       g.add(myprofview, 0, 0);
           mycoursesview.setFitHeight(180);
       mycoursesview.setFitWidth(180);
       g.add(mycoursesview, 0, 1);
           myrecordsview.setFitHeight(180);
    myrecordsview.setFitWidth(180);
       g.add(myrecordsview, 1, 0);
           coursesview.setFitHeight(180);
      coursesview.setFitWidth(180);
       g.add(coursesview, 1, 1);
        myabsencesview.setFitHeight(180);
  myabsencesview.setFitWidth(180);
       g.add(myabsencesview, 0, 2);
       g.add(logout_student, 2, 3);
       applyButtonStyles(logout_student);
       g.setAlignment(Pos.CENTER);
       g.setVgap(20);
       g.setHgap(100);
       applyImageViewStyle(myprofview);
    applyImageViewStyle(mycoursesview);
    applyImageViewStyle(myrecordsview);
    applyImageViewStyle(coursesview);
    applyImageViewStyle(myabsencesview);
                Color backgroundColor = Color.rgb(173, 216, 230, 0.7); // Adjust the RGB values and opacity as needed
    g.setStyle("-fx-background-color: " + toHex(backgroundColor) + ";");
        g.setPadding(new Insets(30));
       return g;
   }
    GridPane Teacher_home_page (){
   GridPane g=new GridPane();
       teacherprofview.setFitHeight(180);
       teacherprofview.setFitWidth(180);
       g.add(teacherprofview, 0, 0);
          teacherstudentview.setFitHeight(180);
    teacherstudentview.setFitWidth(180);
       g.add(teacherstudentview, 1, 0);
           teacherabsencesview.setFitHeight(180);
  teacherabsencesview.setFitWidth(180);
       g.add(teacherabsencesview, 0, 1);
           teachergradesview.setFitHeight(180);
      teachergradesview.setFitWidth(180);
       g.add(teachergradesview, 1, 1);
       
       g.add(logout_teacher, 2, 3);
       applyButtonStyles(logout_teacher);
      g.setAlignment(Pos.CENTER);
       g.setVgap(30);
       g.setHgap(20);
       applyImageViewStyle(teacherabsencesview);
    applyImageViewStyle(teachergradesview);
    applyImageViewStyle(teacherprofview);
    applyImageViewStyle(teacherstudentview);

                Color backgroundColor = Color.rgb(173, 216, 230, 0.7); // Adjust the RGB values and opacity as needed
    g.setStyle("-fx-background-color: " + toHex(backgroundColor) + ";");
        g.setPadding(new Insets(30));
       return g;
   }
   private String toHex(Color color) {
    return String.format("#%02X%02X%02X%02X",
            (int) (color.getRed() * 255),
            (int) (color.getGreen() * 255),
            (int) (color.getBlue() * 255),
            (int) (color.getOpacity() * 255));
}
   private void applyImageViewStyle(ImageView imageView) {
    imageView.setFitHeight(180);
    imageView.setFitWidth(180);

    // Set additional styling as needed
    imageView.setStyle("-fx-border-color: black; -fx-border-width: 2px;");

    // Add a hover effect
    addHoverEffect(imageView);


}
   

private void addHoverEffect(ImageView imageView) {
    ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(200), imageView);
    scaleTransition.setToX(1.1);
    scaleTransition.setToY(1.1);

    imageView.setOnMouseEntered(event -> {
        scaleTransition.playFromStart();
    });

    imageView.setOnMouseExited(event -> {
        scaleTransition.setToX(1);
        scaleTransition.setToY(1);
        scaleTransition.playFromStart();
    });
}

GridPane coursesDesign() throws SQLException{

            Course.courses=d.get_courses();
           GridPane g=new GridPane();
           g.setAlignment(Pos.CENTER);
           g.setHgap(10);
           g.setVgap(20);
           Label i1=new Label("Course ID");
    Label i2=new Label("Title");
    Label i3=new Label("Day");
    Label i4=new Label("Time");
    Label i5=new Label("Number of Credits");
    Label i6=new Label("Passing grade");
    Label i7=new Label("Instructor");
    Label i8=new Label("Faculty name");
    Label i9=new Label("Class Number");
   Label i10=new Label("Available seats");
   i1.setStyle("-fx-alignment: center;");
     i2.setStyle("-fx-alignment: center;");
       i3.setStyle("-fx-alignment: center;");
         i4.setStyle("-fx-alignment: center;");
           i5.setStyle("-fx-alignment: center;");
             i6.setStyle("-fx-alignment: center;");
     i7.setStyle("-fx-alignment: center;");
       i8.setStyle("-fx-alignment: center;");
         i9.setStyle("-fx-alignment: center;");
           i10.setStyle("-fx-alignment: center;");
   g.add(i1, 0, 0);
     g.add(i2, 1, 0);
       g.add(i3, 2, 0);
     g.add(i4, 3, 0);
       g.add(i5, 4, 0);
     g.add(i6, 5, 0);
       g.add(i7, 6, 0);
     g.add(i8, 7, 0);
       g.add(i9, 8, 0);
     g.add(i10, 9, 0);
         applyLabelStyles(i1);
        applyLabelStyles(i2);
        applyLabelStyles(i3);
        applyLabelStyles(i4);
        applyLabelStyles(i5);
        applyLabelStyles(i6);
        applyLabelStyles(i7);
        applyLabelStyles(i8);
        applyLabelStyles(i9);
        applyLabelStyles(i10);
           int i=0;
           for(Course c: Course.courses ){
               i++;
           Label l1=new Label(""+c.id);
           Label l2=new Label(""+c.c_title);
           Label l3=new Label(""+c.c_day);
           Label l4=new Label(""+c.c_time);
                Label l5=new Label(""+c.nb_credits);
                                Label l6=new Label(""+c.passing_grade);
                           Label l7=new Label(""+c.c_instructor);
                           Label l8=new Label(""+c.f_name);
                           Label l9=new Label(""+c.class_nb);
                           Label l10=new Label(""+c.available_seats);
       applyLabelStyles2(l1);
        applyLabelStyles2(l2);
        applyLabelStyles2(l3);
        applyLabelStyles2(l4);
        applyLabelStyles2(l5);
        applyLabelStyles2(l6);
        applyLabelStyles2(l7);
        applyLabelStyles2(l8);
        applyLabelStyles2(l9);
        applyLabelStyles2(l10);
                 g.add(l1, 0, i);
     g.add(l2, 1, i);
       g.add(l3, 2,i);
     g.add(l4, 3, i);
       g.add(l5, 4, i);
     g.add(l6, 5, i);
       g.add(l7, 6, i);
     g.add(l8, 7, i);
       g.add(l9, 8, i);
     g.add(l10, 9, i);
     
     Button b=new Button("Enroll");
               applyButtonStyles(b);
     
 b.setOnAction(e -> {
    try { 
        
        d.enrollCourse(t_username.getText(), c.id);
        
        // Reload the entire scene
        
    } catch (SQLException ex) {
        Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
    }
});

     
             
          g.add(b, 10, i);
         
 
           }
 g.add(course_return, 0, i+1);
    applyButtonStyles(course_return);

           return g;
           }
private void applyLabelStyles(Label label) {
    label.setStyle("-fx-alignment: center; -fx-background-color: #0583D2; -fx-text-fill: #ffffff; -fx-font-size: 14px; -fx-padding: 5px; -fx-min-width: 100px; -fx-font-weight: bold;");
}

private void applyLabelStyles2(Label label) {
    label.setStyle("-fx-alignment: center; -fx-background-color: #0583D2; -fx-text-fill: #ffffff; -fx-font-size: 12px; -fx-padding: 5px; -fx-min-width: 100px; -fx-opacity: 0.7;");
}
GridPane studentcoursesDesign() throws SQLException{

            Course.courses=d.getStudentCourses(t_username.getText());
           GridPane g=new GridPane();
           g.setAlignment(Pos.CENTER);
           g.setHgap(10);
           g.setVgap(20);
           Label i1=new Label("Course ID");
    Label i2=new Label("Title");
    Label i3=new Label("Day");
    Label i4=new Label("Time");
    Label i5=new Label("Number of Credits");
    Label i6=new Label("Passing grade");
    Label i7=new Label("Instructor");
    Label i8=new Label("Faculty name");
    Label i9=new Label("Class Number");
   Label i10=new Label("Available seats");
   i1.setStyle("-fx-alignment: center;");
     i2.setStyle("-fx-alignment: center;");
       i3.setStyle("-fx-alignment: center;");
         i4.setStyle("-fx-alignment: center;");
           i5.setStyle("-fx-alignment: center;");
             i6.setStyle("-fx-alignment: center;");
     i7.setStyle("-fx-alignment: center;");
       i8.setStyle("-fx-alignment: center;");
         i9.setStyle("-fx-alignment: center;");
           i10.setStyle("-fx-alignment: center;");
   g.add(i1, 0, 0);
     g.add(i2, 1, 0);
       g.add(i3, 2, 0);
     g.add(i4, 3, 0);
       g.add(i5, 4, 0);
     g.add(i6, 5, 0);
       g.add(i7, 6, 0);
     g.add(i8, 7, 0);
       g.add(i9, 8, 0);
     g.add(i10, 9, 0);
         applyLabelStyles(i1);
        applyLabelStyles(i2);
        applyLabelStyles(i3);
        applyLabelStyles(i4);
        applyLabelStyles(i5);
        applyLabelStyles(i6);
        applyLabelStyles(i7);
        applyLabelStyles(i8);
        applyLabelStyles(i9);
        applyLabelStyles(i10);
           int i=0;
           for(Course c: Course.courses ){
               i++;
           Label l1=new Label(""+c.id);
           Label l2=new Label(""+c.c_title);
           Label l3=new Label(""+c.c_day);
           Label l4=new Label(""+c.c_time);
                Label l5=new Label(""+c.nb_credits);
                                Label l6=new Label(""+c.passing_grade);
                           Label l7=new Label(""+c.c_instructor);
                           Label l8=new Label(""+c.f_name);
                           Label l9=new Label(""+c.class_nb);
                           Label l10=new Label(""+c.available_seats);
       applyLabelStyles2(l1);
        applyLabelStyles2(l2);
        applyLabelStyles2(l3);
        applyLabelStyles2(l4);
        applyLabelStyles2(l5);
        applyLabelStyles2(l6);
        applyLabelStyles2(l7);
        applyLabelStyles2(l8);
        applyLabelStyles2(l9);
        applyLabelStyles2(l10);
                 g.add(l1, 0, i);
     g.add(l2, 1, i);
       g.add(l3, 2,i);
     g.add(l4, 3, i);
       g.add(l5, 4, i);
     g.add(l6, 5, i);
       g.add(l7, 6, i);
     g.add(l8, 7, i);
       g.add(l9, 8, i);
     g.add(l10, 9, i);
     Button b=new Button("Drop");
               applyButtonStyles(b);
     
 b.setOnAction(e -> {
    try { 
        
        d.dropCourse(t_username.getText(), c.id);
          g.getChildren().removeAll(l1, l2,l3,l4,l5,l6,l7,l8,l9,l10, b);
        // Reload the entire scene
        
    } catch (SQLException ex) {
        Logger.getLogger(App.class.getName()).log(Level.SEVERE, null, ex);
    }
});
    g.add(b, 10, i);
           }
 g.add(my_course_return, 0, i+1);
    applyButtonStyles(course_return);
           return g;
           }


   GridPane profileDesign(){
           Student s= d.student_Info(t_username.getText());
    GridPane g=new GridPane();
    g.setAlignment(Pos.CENTER);
    g.setHgap(15);
     g.setVgap(20);
    Label l1=new Label("My Profile");
    Label l2=new Label("First Name:");
    Label l3=new Label("Last Name:");
    Label l4=new Label("Faculty:");
    Label l5=new Label("Registration Date:");
       Label l6=new Label(""+s.firstname);
   Label l7=new Label(""+s.lastname);
     Label l8=new Label(""+s.f_name);
       Label l9=new Label(""+s.registration_year);

           l1.setStyle(
                "-fx-text-fill: #1260CC; " +
                "-fx-font-size: 22px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " +
                "-fx-font-style: italic;");
            l2.setStyle(
                "-fx-text-fill: #1260CC; " +
                "-fx-font-size: 15px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " );
             l3.setStyle(
                "-fx-text-fill: #1260CC; " +
                "-fx-font-size: 15px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " 
                );
              l4.setStyle(
                "-fx-text-fill: #1260CC; " +
                "-fx-font-size: 15px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " 
                );
               l5.setStyle(
                "-fx-text-fill: #1260CC; " +
                "-fx-font-size: 15px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " 
                );
                l6.setStyle(
                "-fx-text-fill: black; " +
                "-fx-font-size: 15px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " 
                );
                 l7.setStyle(
                "-fx-text-fill: black; " +
                "-fx-font-size: 15px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " 
                );
                  l8.setStyle(
                "-fx-text-fill: black; " +
                "-fx-font-size: 15px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " 
                );
                   l9.setStyle(
                "-fx-text-fill: black; " +
                "-fx-font-size: 15px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " 
                );
Glow glow = new Glow(0);


// Apply the Glow effect to the Label
l1.setEffect(glow);

// Create a Timeline for the glowing animation
Timeline timeline;
         timeline = new Timeline(
                 new KeyFrame(Duration.ZERO, new KeyValue(glow.levelProperty(), 0)),
                 new KeyFrame(Duration.seconds(1), new KeyValue(glow.levelProperty(), 1))
         );

// Set the cycle count to indefinite for continuous animation
timeline.setCycleCount(Timeline.INDEFINITE);

// Auto-reverse the animation to make it smooth
timeline.setAutoReverse(true);

// Play the animation
timeline.play();


         g.add(studentprofileview, 0, 0);
             g.add(l1, 1, 0);
              g.add(l2, 0, 2);
               g.add(l6, 1, 2);
                g.add(l3, 0, 3);
                 g.add(l7, 1, 3);
                  g.add(l4, 0, 4);
                     g.add(l8, 1, 4);
                     g.add(l5, 0, 5);
                     g.add(l9, 1, 5);
                     g.add(profile_return, 2, 6);
                     applyButtonStyles(profile_return);
                     studentprofileview.setFitHeight(120);
                     studentprofileview.setFitWidth(150);
                     Color backgroundColor = Color.rgb(173, 216, 230, 0.7); // Adjust the RGB values and opacity as needed
    g.setStyle("-fx-background-color: " + toHex(backgroundColor) + ";");


    
    
                     return g;
    }
   
   GridPane gradesDesign() throws SQLException
   {
       ArrayList<Grades> grades =new ArrayList<>();
  grades=d.getStudentGrades(t_username.getText());
           GridPane g=new GridPane();
           g.setAlignment(Pos.CENTER);
           g.setHgap(10);
           g.setVgap(20);
           Label i0=new Label("My Grades");
           Label i1=new Label("Course Title");
    Label i2=new Label("Grade");
    Label i3=new Label("State");
      i0.setStyle(
                "-fx-text-fill: #1260CC; " +
                "-fx-font-size: 22px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " +
                "-fx-font-style: italic;");
Glow glow = new Glow(0);
 
 
// Apply the Glow effect to the Label
i0.setEffect(glow);
 
// Create a Timeline for the glowing animation
Timeline timeline = new Timeline(
        new KeyFrame(Duration.ZERO, new KeyValue(glow.levelProperty(), 0)),
        new KeyFrame(Duration.seconds(1), new KeyValue(glow.levelProperty(), 1))
);
 
// Set the cycle count to indefinite for continuous animation
timeline.setCycleCount(Timeline.INDEFINITE);
 
// Auto-reverse the animation to make it smooth
timeline.setAutoReverse(true);
 
// Play the animation
timeline.play();
   Color backgroundColor = Color.rgb(173, 216, 230, 0.7); // Adjust the RGB values and opacity as needed
    g.setStyle("-fx-background-color: " + toHex(backgroundColor) + ";");
   i1.setStyle("-fx-alignment: center;");
     i2.setStyle("-fx-alignment: center;");
       i3.setStyle("-fx-alignment: center;");
     
   g.add(i0, 0, 0);
     g.add(i1, 0, 1);
       g.add(i2, 1, 1);
       g.add(i3, 2, 1);
   
         applyLabelStyles(i1);
        applyLabelStyles(i2);
        applyLabelStyles(i3);
      
           int i=1;
           for(Grades gr: grades ){
               i++;
           Label l1=new Label(""+gr.c_title);
           Label l2=new Label(""+gr.grade);
           Label l3=new Label(""+gr.state);
         
       applyLabelStyles2(l1);
        applyLabelStyles2(l2);
        applyLabelStyles2(l3);
 
                 g.add(l1, 0, i);
     g.add(l2, 1, i);
       g.add(l3, 2,i);

 
     

           }
 g.add(grades_return, 3, i+1);
    applyButtonStyles(grades_return);
           return g;
       
   }
    GridPane absencesDesign() throws SQLException
   {
       ArrayList<Absence> absences =new ArrayList<>();
  absences=d.getStudentAbsences(t_username.getText());
           GridPane g=new GridPane();
           g.setAlignment(Pos.CENTER);
           g.setHgap(10);
           g.setVgap(20);
           Label i0=new Label("My Absences");
           Label i1=new Label("Course Title");
    Label i2=new Label("Absence Date");
 
      i0.setStyle(
                "-fx-text-fill: #1260CC; " +
                "-fx-font-size: 22px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " +
                "-fx-font-style: italic;");
Glow glow = new Glow(0);
 
 
// Apply the Glow effect to the Label
i0.setEffect(glow);
 
// Create a Timeline for the glowing animation
Timeline timeline = new Timeline(
        new KeyFrame(Duration.ZERO, new KeyValue(glow.levelProperty(), 0)),
        new KeyFrame(Duration.seconds(1), new KeyValue(glow.levelProperty(), 1))
);
 
// Set the cycle count to indefinite for continuous animation
timeline.setCycleCount(Timeline.INDEFINITE);
 
// Auto-reverse the animation to make it smooth
timeline.setAutoReverse(true);
 
// Play the animation
timeline.play();
   Color backgroundColor = Color.rgb(173, 216, 230, 0.7); // Adjust the RGB values and opacity as needed
    g.setStyle("-fx-background-color: " + toHex(backgroundColor) + ";");
   i1.setStyle("-fx-alignment: center;");
     i2.setStyle("-fx-alignment: center;");
      
     
   g.add(i0, 0, 0);
     g.add(i1, 0, 1);
       g.add(i2, 1, 1);
     
   
         applyLabelStyles(i1);
        applyLabelStyles(i2);
      
      
           int i=1;
           for(Absence a: absences ){
               i++;
           Label l1=new Label(""+a.c_title);
           Label l2=new Label(""+a.absence_date);
         
         
       applyLabelStyles2(l1);
        applyLabelStyles2(l2);
      
 
                 g.add(l1, 0, i);
     g.add(l2, 1, i);
       

 
     

           }
 g.add(absence_return, 2, i+1);
    applyButtonStyles(absence_return);
           return g;
       
   }
    GridPane add_student_design()
    {
        GridPane g= new GridPane();
         Label l0=new Label ("Add Student ");
        Label l1=new Label ("Student username: ");
         Label l2=new Label ("Student password: ");
          Label l3=new Label ("Student firstname: ");
           Label l4=new Label ("Student lastname: ");
            Label l5=new Label ("Student registration date: ");
             Label l6=new Label ("Student Faculty: ");
             g.add(l0, 0, 0);
g.add(l1, 0, 1);
g.add(l2, 0, 2);
g.add(l3, 0, 3);
g.add(l4, 0, 4);
g.add(l5, 0, 5);
g.add(l6, 0, 6);

g.add(new_username, 1, 1);
g.add(new_password, 1, 2);
g.add(new_fname, 1, 3);
g.add(new_lname, 1, 4);
g.add(new_registration_date, 1, 5);
g.add(new_faculty, 1, 6);

g.add(b_add_student, 2, 7);
applyButtonStyles(b_add_student);

g.add(add_student_return, 2, 8);

                         applyButtonStyles(add_student_return);
                         g.setAlignment(Pos.CENTER);
           g.setHgap(10);
           g.setVgap(20);
           Glow glow = new Glow(0);
 
     
      
           l0.setStyle(
                "-fx-text-fill: #1260CC; " +
                "-fx-font-size: 15px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " +
                "-fx-font-style: italic;");
                   l1.setStyle(
                "-fx-text-fill: #1260CC; " +
                "-fx-font-size: 15px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " +
                "-fx-font-style: italic;");
                           l2.setStyle(
                "-fx-text-fill: #1260CC; " +
                "-fx-font-size: 15px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " +
                "-fx-font-style: italic;");
                                   l3.setStyle(
                "-fx-text-fill: #1260CC; " +
                "-fx-font-size: 15px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " +
                "-fx-font-style: italic;");
                                           l4.setStyle(
                "-fx-text-fill: #1260CC; " +
                "-fx-font-size: 15px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " +
                "-fx-font-style: italic;");
                                                   l5.setStyle(
                "-fx-text-fill: #1260CC; " +
                "-fx-font-size: 15px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " +
                "-fx-font-style: italic;");
                                                           l6.setStyle(
                "-fx-text-fill: #1260CC; " +
                "-fx-font-size: 15px; " +
                "-fx-font-family: 'Arial'; " +
                "-fx-font-weight: bold; " +
                "-fx-font-style: italic;");
// Apply the Glow effect to the Label
l0.setEffect(glow);
 
// Create a Timeline for the glowing animation
Timeline timeline = new Timeline(
        new KeyFrame(Duration.ZERO, new KeyValue(glow.levelProperty(), 0)),
        new KeyFrame(Duration.seconds(1), new KeyValue(glow.levelProperty(), 1))
);
 
// Set the cycle count to indefinite for continuous animation
timeline.setCycleCount(Timeline.INDEFINITE);
 
// Auto-reverse the animation to make it smooth
timeline.setAutoReverse(true);
 
// Play the animation
timeline.play();
   Color backgroundColor = Color.rgb(173, 216, 230, 0.7); // Adjust the RGB values and opacity as needed
    g.setStyle("-fx-background-color: " + toHex(backgroundColor) + ";");
                         
        return g;
    }
private void applyButtonStyles(Button button) {
    // Blue background with white text
    button.setStyle(
        "-fx-font-size: 12px; -fx-padding: 10px;" +
        "-fx-background-color: #1260CC; -fx-text-fill: white;"
    );

    // Scaling effect on mouse hover
    button.setOnMouseEntered(e -> button.setScaleX(1.1));
    button.setOnMouseExited(e -> button.setScaleX(1.0));
}

    public static void main(String[] args) {
        launch();
    }
    
    static class Database {
            Connection connection;
private App app;

    // Constructor to initialize the App instance
    public Database(App app) {
        this.app = app;
    }
        void connect() throws ClassNotFoundException {

         String jdbcUrl = "jdbc:mysql://localhost:3306/sis";
	        String username = "root";
	        String password = "oracle";
         

	        try {
                    Class.forName("com.mysql.cj.jdbc.Driver");

	          connection = DriverManager.getConnection(jdbcUrl, username, password);
	            System.out.println("Connected to the database!");
	            // Perform database operations here
	            // Don't forget to close the connection after use:
	            // connection.close();
	        } catch (SQLException e) {
	            System.err.println("Error connecting to the database: " + e.getMessage());
	        }
        }
        
        
  boolean validate_instructor(String i_username, String i_password) {
    ResultSet result = null;

    try {
        // Using prepared statement to prevent SQL injection
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM instructors WHERE username = ?");
        statement.setString(1, i_username);

        result = statement.executeQuery();

        if (result.next()) {
            // Use equals for string comparison
            if (result.getString("i_password").equals(i_password)) {
                return true;
            }
        }
    } catch (SQLException ex) {
        Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (result != null) {
                result.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return false;
}
  
   boolean validate_student(String s_username, String s_password) {
    ResultSet result = null;

    try {
        // Using prepared statement to prevent SQL injection
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM students WHERE username = ?");
        statement.setString(1, s_username);

        result = statement.executeQuery();

        if (result.next()) {
            // Use equals for string comparison
            if (result.getString("s_password").equals(s_password)) {
                return true;
            }
        }
    } catch (SQLException ex) {
        Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (result != null) {
                result.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return false;
}
   
   void enrollCourse(String s_username, int c_id) throws SQLException {
    // Check if the student is already enrolled in the course
    String checkEnrollmentQuery = "SELECT COUNT(*) FROM enrollement WHERE s_username = ? AND c_id = ?";
    try (PreparedStatement checkEnrollmentPst = connection.prepareStatement(checkEnrollmentQuery)) {
        checkEnrollmentPst.setString(1, s_username);
        checkEnrollmentPst.setInt(2, c_id);
        try (ResultSet resultSet = checkEnrollmentPst.executeQuery()) {
            if (resultSet.next() && resultSet.getInt(1) > 0) {
                // The student is already enrolled in the course
                System.out.println("Error: Student is already enrolled in the course.");
          app.showAlert(Alert.AlertType.ERROR, "Error", "Student is already enrolled in the course.");
                return;
            }
        }
    }

    // Enroll the student in the course
    String enrollmentQuery = "INSERT INTO enrollement (s_username, c_id) VALUES (?, ?)";
    String decreaseSeatsQuery = "UPDATE courses SET available_seats = available_seats - 1 WHERE id = ?";

    try (PreparedStatement enrollmentPst = connection.prepareStatement(enrollmentQuery);
         PreparedStatement decreaseSeatsPst = connection.prepareStatement(decreaseSeatsQuery)) {

        // Enroll the student in the course
        enrollmentPst.setString(1, s_username);
        enrollmentPst.setInt(2, c_id);
        int enrollmentRowsAffected = enrollmentPst.executeUpdate();

        if (enrollmentRowsAffected > 0) {
            // If enrollment is successful, decrease available_seats
            decreaseSeatsPst.setInt(1, c_id);
            int decreaseSeatsRowsAffected = decreaseSeatsPst.executeUpdate();

            if (decreaseSeatsRowsAffected > 0) {
                System.out.println("Course enrolled successfully! Available seats decreased.");
                  app.showAlert(Alert.AlertType.INFORMATION, "Information", "Course enrolled successfully!");

            } else {
                System.out.println("Error decreasing available seats!");
            }
        } else {
            System.out.println("Error enrolling courses!");
        }
    }
}
 void dropCourse(String s_username, int c_id) throws SQLException {
    // Check if the student is already enrolled in the course

    // Enroll the student in the course
    String dropQuery = "DELETE FROM enrollement WHERE s_username=? AND c_id=?";
    String increaseSeatsQuery = "UPDATE courses SET available_seats = available_seats + 1 WHERE id = ?";

    try (PreparedStatement enrollmentPst = connection.prepareStatement(dropQuery);
         PreparedStatement decreaseSeatsPst = connection.prepareStatement(increaseSeatsQuery)) {

        // Enroll the student in the course
        enrollmentPst.setString(1, s_username);
        enrollmentPst.setInt(2, c_id);
        int enrollmentRowsAffected = enrollmentPst.executeUpdate();

        if (enrollmentRowsAffected > 0) {
            // If enrollment is successful, decrease available_seats
            decreaseSeatsPst.setInt(1, c_id);
            int decreaseSeatsRowsAffected = decreaseSeatsPst.executeUpdate();

            if (decreaseSeatsRowsAffected > 0) {
                System.out.println("Course dropped successfully! Available seats increased.");
                app.showAlert(Alert.AlertType.INFORMATION, "Information", "Course dropped successfully!");
            } else {
                System.out.println("Error increasing available seats!");
            }
        } else {
            System.out.println("Error dropping courses!");
        }
    }
}

           
           
    ArrayList<Course>  get_courses() throws SQLException
  {
    ResultSet result = null;
ArrayList<Course> courses =new ArrayList<>();
    try {
        // Using prepared statement to prevent SQL injection
        PreparedStatement statement = connection.prepareStatement("SELECT * FROM courses");
        result = statement.executeQuery();
 
        while (result.next()) {
           Course c=new Course(result.getInt("id"),result.getInt("nb_credits"),result.getInt("available_seats"),result.getString("c_title"),result.getString("c_day"),result.getString("c_instructor"),result.getString("class_nb"),result.getString("f_name"),result.getDouble("passing_grade"),result.getTime("c_time"));
        courses.add(c);
        }
        }
     catch (SQLException ex) {
        Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (result != null) {
                result.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
 
    return courses;
        }
    
    
    ArrayList<Course> getStudentCourses(String s_username) throws SQLException {
    ResultSet result = null;
    ArrayList<Course> courses = new ArrayList<>();

    try {
        // Using a JOIN operation to fetch relevant information from both tables
        String query = "SELECT c.* FROM courses c JOIN enrollement e ON c.id = e.c_id WHERE e.s_username = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, s_username);

        result = statement.executeQuery();

        while (result.next()) {
            Course c = new Course(
                    result.getInt("id"),
                    result.getInt("nb_credits"),
                    result.getInt("available_seats"),
                    result.getString("c_title"),
                    result.getString("c_day"),
                    result.getString("c_instructor"),
                    result.getString("class_nb"),
                    result.getString("f_name"),
                    result.getDouble("passing_grade"),
                    result.getTime("c_time")
            );
            courses.add(c);
        }
    } catch (SQLException ex) {
        Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (result != null) {
                result.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return courses;
}

    

  Student student_Info(String s_username){
          ResultSet result = null;
     Student s=null;
    try {
        // Using prepared statement to prevent SQL injection
       PreparedStatement statement = connection.prepareStatement("SELECT * FROM students where username=?");
         statement.setString(1, s_username);
        result = statement.executeQuery();
        while (result.next()) {
           s=new Student(result.getString("username"),result.getString("s_password"),result.getString("firstname"),result.getString("lastname"),result.getString("f_name"),result.getDate("registration_year"));
        }
        }
     catch (SQLException ex) {
        Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (result != null) {
                result.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return s;

    }
 
      ArrayList<Grades> getStudentGrades(String s_username) throws SQLException {
    ResultSet result = null;
    ArrayList<Grades>grades = new ArrayList<>();

    try {
        // Using a JOIN operation to fetch relevant information from both tables
        String query = "SELECT  c.c_title as c_title , g.grade as grade, g.state as state  FROM grades g , enrollement e, courses c  where c.id = e.c_id and g.e_id=e.id and e.s_username = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, s_username);

        result = statement.executeQuery();

        while (result.next()) {
                Grades g;
            g = new Grades(
                    result.getString("c_title"),
                    result.getString("state"),
                    result.getDouble("grade")
                   
            );
           grades.add(g);
        }
    } catch (SQLException ex) {
        Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (result != null) {
                result.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return grades;
}
ArrayList<Absence> getStudentAbsences(String s_username) throws SQLException {
    ResultSet result = null;
    ArrayList<Absence> absences = new ArrayList<>();

    try {
        // Query to fetch all absences for the student
        String query = "SELECT c.c_title as c_title, a.absence_date as absence_date " +
                       "FROM absences a, enrollement e, courses c " +
                       "WHERE c.id = e.c_id AND a.e_id = e.id AND e.s_username = ?";

        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, s_username);

        result = statement.executeQuery();

        while (result.next()) {
            String courseTitle = result.getString("c_title");
            Date absenceDate = result.getDate("absence_date");

            Absence a = new Absence(courseTitle, absenceDate, 0); // Set absence count to 0
            absences.add(a);
        }

        // Query to count absences per course and show warning if count > 4
        String countQuery = "SELECT c.c_title as c_title, COUNT(a.id) as absence_count " +
                            "FROM absences a, enrollement e, courses c " +
                            "WHERE c.id = e.c_id AND a.e_id = e.id AND e.s_username = ? " +
                            "GROUP BY c.id " +
                            "HAVING absence_count > 4";

        PreparedStatement countStatement = connection.prepareStatement(countQuery);
        countStatement.setString(1, s_username);

        ResultSet countResult = countStatement.executeQuery();

        while (countResult.next()) {
            String courseTitle = countResult.getString("c_title");
            int absenceCount = countResult.getInt("absence_count");

            // Display warning if absenceCount exceeds 4
            String warningMessage = "You're at risk of being dropped from the course: " + courseTitle;
            showAlert(Alert.AlertType.WARNING, "Warning", warningMessage);
        }

    } catch (SQLException ex) {
        Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
    } finally {
        try {
            if (result != null) {
                result.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    return absences;
}

void addStudent(String username, String s_password, String firstname, String lastname, Date registrationDate, String f_name) {
    // Check if any of the fields is empty
    if (username.isEmpty() || s_password.isEmpty() || firstname.isEmpty() || lastname.isEmpty() || f_name.isEmpty() || registrationDate == null) {
        System.out.println("All fields are required. Cannot add student.");
        
        showAlert(Alert.AlertType.ERROR, "Error", "All fields are required. Cannot add student.");
        return;
    }

    String query = "INSERT INTO students (username, s_password, firstname, lastname, registration_year, f_name) VALUES (?, ?, ?, ?, ?, ?)";

    try (PreparedStatement statement = connection.prepareStatement(query)) {
        statement.setString(1, username);
        statement.setString(2, s_password);
        statement.setString(3, firstname);
        statement.setString(4, lastname);

        // Use the provided registrationDate
        statement.setDate(5, new java.sql.Date(registrationDate.getTime()));

        statement.setString(6, f_name);

        // Execute the insert statement
        statement.executeUpdate();

        System.out.println("Student added successfully.");
        showAlert(Alert.AlertType.INFORMATION, "Success", "Student added successfully!");

    } catch (SQLException ex) {
        ex.printStackTrace();
        // Handle exceptions as needed
    }
}







// Helper method to show an alert
private void showAlert(Alert.AlertType alertType, String title, String content) {
    Alert alert = new Alert(alertType);
    alert.setTitle(title);
    alert.setHeaderText(null);
    alert.setContentText(content);
    alert.showAndWait();
}

    }
   public void showAlert(AlertType alertType, String title, String contentText) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(contentText);
        alert.showAndWait();
    }
}